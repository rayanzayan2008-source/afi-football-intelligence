export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    // API-Football proxy: the secret stays on the server, never in browser code.
    if (url.pathname === "/api/football") {
      if (request.method !== "GET") {
        return json({ error: "Method not allowed" }, 405);
      }
      if (!env.API_FOOTBALL_KEY) {
        return json({ error: "Missing Cloudflare secret API_FOOTBALL_KEY" }, 500);
      }

      const action = url.searchParams.get("action");
      let endpoint = "";

      if (action === "live") {
        endpoint = "/fixtures?live=all";
      } else if (action === "fixtures") {
        const date = url.searchParams.get("date");
        if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
          return json({ error: "A valid date=YYYY-MM-DD is required" }, 400);
        }
        endpoint = `/fixtures?date=${encodeURIComponent(date)}`;
      } else if (action === "analysis") {
        const fixture = url.searchParams.get("fixture");
        if (!fixture || !/^\d+$/.test(fixture)) {
          return json({ error: "A valid fixture ID is required" }, 400);
        }
        const [predictions, odds] = await Promise.all([
          provider(`/predictions?fixture=${fixture}`, env.API_FOOTBALL_KEY),
          provider(`/odds?fixture=${fixture}`, env.API_FOOTBALL_KEY)
        ]);
        return json({
          predictions: predictions.data,
          odds: odds.data,
          predictionsError: predictions.error,
          oddsError: odds.error
        }, 200, {
          "X-API-Requests-Remaining":
            predictions.remaining ?? odds.remaining ?? "unknown"
        });
      } else {
        return json({ error: "Unknown action. Use fixtures, live, or analysis." }, 400);
      }

      const result = await provider(endpoint, env.API_FOOTBALL_KEY);
      if (result.error) return json({ error: result.error }, result.status || 502);
      return json(result.data, 200, {
        "X-API-Requests-Remaining": result.remaining ?? "unknown"
      });
    }

    // Serve the website from the configured static-assets binding.
    return env.ASSETS.fetch(request);
  }
};

async function provider(path, key) {
  try {
    const response = await fetch(`https://v3.football.api-sports.io${path}`, {
      headers: { "x-apisports-key": key }
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const message = data?.errors
        ? JSON.stringify(data.errors)
        : `API-Football returned HTTP ${response.status}`;
      return { error: message, status: response.status };
    }
    if (data.errors && Object.keys(data.errors).length) {
      return { error: JSON.stringify(data.errors), status: 502 };
    }
    return {
      data,
      remaining: response.headers.get("x-ratelimit-requests-remaining")
    };
  } catch (error) {
    return { error: `Provider connection failed: ${error.message}`, status: 502 };
  }
}

function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      ...extraHeaders
    }
  });
}
